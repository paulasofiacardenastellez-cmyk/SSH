# SSH Quest 🍄🔐

Juego educativo HTML sobre SSH.

## Publicar en GitHub Pages
1. Crea un repositorio nuevo en GitHub.
2. Sube `index.html` en la raíz del repositorio.
3. Ve a Settings → Pages.
4. En Build and deployment selecciona Deploy from a branch.
5. Selecciona la rama `main` y la carpeta `/ (root)`.
6. Guarda y espera a que GitHub genere el enlace público.

## Publicar en Netlify
Arrastra la carpeta `ssh-quest-publicar` a Netlify Drop o sube `index.html`.
